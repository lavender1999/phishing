document.addEventListener('DOMContentLoaded', function() {
  result()
}, false);

function result() {
  chrome.tabs.getSelected(null, function (tab) {
    d = document;

    var div = document.querySelector(".result");
    var urlname = tab.url;
    $.ajax({
      data: {
        name: urlname,
      },
      type: "GET",
      url: "http://127.0.0.1:5000/result",
    })
      .always(
        (div.innerHTML =
          '<div class="loading-dots mt-4"><div class="loading-dots--dot"></div><div class="loading-dots--dot"></div><div class="loading-dots--dot"></div></div>')
      )
      .done(function (data) {
        if (data.error) {
          alert(data.error);
        } else {
          splitData = data.split(",");
          var newHTML =
            '<div class="result-dis mt-4"><span style="color:black;">' +
            splitData[1] +
            "</span><h3>" +
            splitData[0] +
            "</h3>";
          if (splitData[0] == "Phishing URL") {
            newHTML +=
              '<div style="color:black;">This Website is a Phishing Site. Please do visit at your own Risk. The site can steal your personal information or credit card details if provided.</div></div>';
          } else {
            newHTML +=
              '<div style="color:black;">This site looks Secure. The information provided won\'t guarantee any Safety by visiting this site. </div></div>';
          }
          div.innerHTML = newHTML;
        }
      });
  });
}


